<footer class="bg-dark text-white text-center py-3" style="margin-top: 5%;">
        <div class="container">
            <div class="row">
              <div class="col-sm">
                <h3>Autóbérlés Székesfehérváron</h3>
                
               <p>Ha a legmegbizhatóbb helyet keresi autóbérlésre Székesfehérváron minket válasszon!</p>
              </div>
              <div class="col-sm">
                <h3>Kapcsolat</h3>
                
               <p><i class="fa-solid fa-phone"></i>Telefonszám:+33 20 222 2222</p>
               <p>Email:szekesfehervarberles@gmail.com</p>
              </div>
              <div class="col-sm">
               <h3>Elérhetőség</h3>
               
               <p>Hétfő-Péntek:  07:00 - 17:00</p>
               <p>Szombat:   07:00 - 17:00</p>
               <p>Vasárnap: Zárva</p>
              
              </div>
            </div>
</footer>

