
<div class="container mt-5 ">
    <div class="row">
        <div class="col-md-12" style="font-size: 1vw;">
      <h5> <p> +36 70 - 741 - 6351 központi elérhetőségünk, non stop ügyelettel</p>  

<p>----------------------------</p>

<p>Ha informálódni szeretne az autóbérlésről, kérdése van, utazását tervezi:</p>

<p>+36 70 412 5391, Whats up-on is</p>

<p>----------------------------</p>

<p>8000 Székesfehérvár,</p>

<p>Új Csóri út 8/a</p>

<p>------------------------------------</p>
</h5>  
 <div id="map" style="width: auto; height: 40vh; margin: 4vw auto; ">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1611.7033315951364!2d18.38026763223884!3d47.20579801298704!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4769f6401ab31027%3A0x91c41b96222d7821!2zTGVnZW5kIEF1dMOzYsOpcmzDqXMgU3rDqWtlc2ZlaMOpcnbDoXI!5e0!3m2!1shu!2shu!4v1695903674462!5m2!1shu!2shu" style="display: block; width: 100%; height: 100%;"  frameborder="0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
 </div>
</div>
</div>
</div>
          
       


       